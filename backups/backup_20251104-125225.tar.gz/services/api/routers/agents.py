# services/api/routers/agents.py
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Request, Query
from fastapi.responses import JSONResponse, FileResponse
from typing import Dict, Any, Optional
import pandas as pd
import io, json, uuid, os
from pathlib import Path
from datetime import datetime, timezone

router = APIRouter()

# ── Import concrete runners (no stubs)
try:
    from agents.asset_appraisal.runner import run as run_asset_appraisal  # noqa
except Exception as e:
    raise RuntimeError(f"Missing or broken asset_appraisal runner: {e}") from e

try:
    from agents.credit_appraisal.runner import run as run_credit_appraisal  # noqa
except Exception as e:
    raise RuntimeError(f"Missing or broken credit_appraisal runner: {e}") from e

AGENT_REGISTRY: Dict[str, Dict[str, Any]] = {
    "asset_appraisal": {
        "id": "asset_appraisal",
        "display_name": "Asset Appraisal Agent",
        "aliases": ["asset"],
        "runner": run_asset_appraisal,
    },
    "credit_appraisal": {
        "id": "credit_appraisal",
        "display_name": "Credit Appraisal Agent",
        "aliases": ["credit"],
        "runner": run_credit_appraisal,
    },
}

_ALIAS_TO_CANON: Dict[str, str] = {}
for canon, meta in AGENT_REGISTRY.items():
    _ALIAS_TO_CANON[canon] = canon
    for al in meta.get("aliases", []):
        _ALIAS_TO_CANON[al] = canon

def _canonicalize(agent_id: str) -> str:
    cid = _ALIAS_TO_CANON.get(agent_id)
    if not cid:
        raise HTTPException(status_code=404, detail=f"Unknown agent '{agent_id}'")
    return cid

def _read_csv_from_upload(upload: UploadFile) -> pd.DataFrame:
    raw = upload.file.read()
    try:
        return pd.read_csv(io.BytesIO(raw))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"CSV parse error: {e}") from e

# where we persist run artifacts (…/services/api/.runs)
RUNS_DIR = Path(__file__).resolve().parent.parent / ".runs"
RUNS_DIR.mkdir(parents=True, exist_ok=True)

@router.get("/v1/agents")
def list_agents():
    items = []
    for meta in AGENT_REGISTRY.values():
        items.append({
            "id": meta["id"],
            "display_name": meta.get("display_name", meta["id"]),
            "aliases": meta.get("aliases", []),
        })
    return {"agents": items}

@router.get("/v1/agents/list")
def list_agents_alt():
    return list_agents()

@router.post("/v1/agents/{agent_id}/run")
async def run_agent(
    agent_id: str,
    file: UploadFile = File(..., description="CSV file"),

    # Legacy / classic fields (kept for compat)
    use_llm: Optional[str] = Form(None),
    llm: Optional[str] = Form(None),
    flavor: Optional[str] = Form(None),
    selected_model: Optional[str] = Form(None),
    agent_name: Optional[str] = Form(None),
    rule_mode: Optional[str] = Form(None),
    max_dti: Optional[str] = Form(None),
    min_ndi_ratio: Optional[str] = Form(None),
    min_emp: Optional[str] = Form(None),
    min_hist: Optional[str] = Form(None),
    max_delin: Optional[str] = Form(None),
    req_min: Optional[str] = Form(None),
    req_max: Optional[str] = Form(None),
    allowed_terms: Optional[str] = Form(None),
    monthly_relief: Optional[str] = Form(None),
    threshold: Optional[str] = Form(None),
    target_approval_rate: Optional[str] = Form(None),
    random_band: Optional[str] = Form(None),
    random_approval_band: Optional[str] = Form(None),
    currency_code: Optional[str] = Form(None),
    currency_symbol: Optional[str] = Form(None),

    # New UI names
    use_llm_narrative: Optional[str] = Form(None),
    llm_model: Optional[str] = Form(None),
    hardware_flavor: Optional[str] = Form(None),
    min_employment_years: Optional[str] = Form(None),
    max_debt_to_income: Optional[str] = Form(None),
    min_credit_history_length: Optional[str] = Form(None),
    max_num_delinquencies: Optional[str] = Form(None),
    requested_amount_min: Optional[str] = Form(None),
    requested_amount_max: Optional[str] = Form(None),
    loan_term_months_allowed: Optional[str] = Form(None),
    monthly_debt_relief: Optional[str] = Form(None),
):
    canon = _canonicalize(agent_id)
    df = _read_csv_from_upload(file)

    # normalize params into a single dict
    params: Dict[str, Any] = {
        "use_llm": (use_llm or use_llm_narrative),
        "llm": (llm or llm_model),
        "flavor": (flavor or hardware_flavor),
        "selected_model": selected_model,
        "agent_name": (agent_name or canon),
        "rule_mode": rule_mode,

        "currency_code": currency_code,
        "currency_symbol": currency_symbol,

        "max_dti": (max_dti or max_debt_to_income),
        "min_emp": (min_emp or min_employment_years),
        "min_hist": (min_hist or min_credit_history_length),
        "max_delin": (max_delin or max_num_delinquencies),
        "req_min": (req_min or requested_amount_min),
        "req_max": (req_max or requested_amount_max),
        "allowed_terms": (allowed_terms or loan_term_months_allowed),
        "monthly_relief": (monthly_relief or monthly_debt_relief),

        "threshold": threshold,
        "target_approval_rate": target_approval_rate,
        "random_band": (random_band or random_approval_band),
    }
    # coerce boolean-ish strings
    for k in ("use_llm", "random_band"):
        v = params.get(k)
        if isinstance(v, str):
            params[k] = v.strip().lower() in ("true", "1", "yes", "on")

    runner = AGENT_REGISTRY[canon]["runner"]
    out_df = runner(df, params)
    if not isinstance(out_df, pd.DataFrame):
        raise HTTPException(status_code=500, detail="Runner did not return a DataFrame")

    # create a run_id and persist artifacts so the UI can fetch them later
    run_id = f"{canon}_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}_{uuid.uuid4().hex[:8]}"
    csv_path = RUNS_DIR / f"{run_id}.merged.csv"
    json_path = RUNS_DIR / f"{run_id}.merged.json"

    out_df.to_csv(csv_path, index=False)
    out_df.to_json(json_path, orient="records")

    meta = {
        "runner_used": f"{runner.__module__}.run",
        "rows": int(out_df.shape[0]),
        "cols": int(out_df.shape[1]),
        "currency_code": params.get("currency_code"),
        "currency_symbol": params.get("currency_symbol"),
    }

    # keep result body tiny – UI will fetch via /v1/runs/{run_id}/report
    return JSONResponse(content={
        "run_id": run_id,
        "agent_id": canon,
        "result": [],         # intentionally empty (prevents huge payloads)
        "meta": meta,
        "artifacts": {        # optional hints; UI can ignore and still call /v1/runs/...
            "csv_path": str(csv_path),
            "json_path": str(json_path),
        }
    })

@router.get("/v1/runs/{run_id}/report")
def get_run_report(run_id: str, format: str = Query("csv", regex="^(csv|json)$")):
    """
    Minimal endpoint the UI expects:
    GET /v1/runs/{run_id}/report?format=csv|json
    """
    csv_path = RUNS_DIR / f"{run_id}.merged.csv"
    json_path = RUNS_DIR / f"{run_id}.merged.json"

    if format == "csv":
        if not csv_path.exists():
            raise HTTPException(status_code=404, detail="CSV report not found")
        return FileResponse(path=str(csv_path), media_type="text/csv", filename=f"{run_id}.csv")

    # format == "json"
    if not json_path.exists():
        raise HTTPException(status_code=404, detail="JSON report not found")
    return FileResponse(path=str(json_path), media_type="application/json", filename=f"{run_id}.json")
